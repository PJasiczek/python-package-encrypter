from setuptools import setup, find_packages

setup(
    name='python-package-encrypter',
    version='0.1',
    license='MIT',
    description='An package include functions square encryptor',
    install_requires=['numpy'],
    url='https://git.e-science.pl/pjasiczek225933/81c_PJasiczek_Python',
    author='Piotr Jasiczek',
    author_email='225933@student.pwr.edu.pl'
)